//
//  AAContentTypes.h
//  AASDK
//
//  Created by hollarab on 1/11/17.
//  Copyright © 2017 AdAdapted. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 \brief An item the user may add to their list.
 
 See: \ref payload_content
 */
@interface AADetailedListItem : NSObject

/** For AdAdapted use */
@property (nonnull) NSString* payloadId;
/** For AdAdapted use */
@property (nonnull) NSString* trackingId;
/** Text to add to list */
@property (nonnull) NSString* productTitle;
/** https image URL */
@property (nullable) NSURL* productImageURL;
/** product brand */
@property (nullable) NSString* productBrand;
/** A category for the product */
@property (nullable) NSString* productCategory;
/** barcode */
@property (nullable) NSString* productBarcode __attribute__((deprecated("updated v5.1.8, please access with 'productUpc'")));
/** discount - things like 10% or $3 off */
@property (nullable) NSString* productDiscount;
/** description - extra text information about the product */
@property (nullable) NSString* productDescription;
/** product UPC */
@property (nullable) NSString* productUpc;
/** retailer sku */
@property (nullable) NSString* retailerSku;

/**
 Creates AADetailedListItem from dictionary with referance to payload

 @param dictionary valid data
 @param payloadId id for payload
 @return null or valid object
 */
+(nullable instancetype)parseFromItemDictionary:(nullable NSDictionary*)dictionary forPayload:(nonnull NSString*)payloadId;

/**
 Returns item as a dictionary.

 @return a dictionary that includes a payload_id field along with the object's properties.
 */
- (nullable NSDictionary*)toDictionary;

@end



/**
 \brief A container for one or more AADetailedListItems that may have it's own branding and message.
 */
@interface AAContentPayload : NSObject

/** For AdAdapted use */
@property (nonnull) NSString *payloadId;
/** Message to display the user */
@property (nullable) NSString *payloadMessage;
/** https image URL */
@property (nullable) NSURL* payloadImageURL;
/** always 'detailed_list_items' at this time */
@property (nonnull) NSString *payloadType;
/** array of items */
@property (nonnull) NSArray<AADetailedListItem*> *detailedListItems;

/** 
 Create from a dictionary
 
 \param dictionary dictionary*/
+(nullable instancetype)parseFromDictionary:(nullable NSDictionary*)dictionary;

/** \brief Acknowledge payload received and items added to a list.
 */
- (void)acknowledge;

/** \brief Mark payload received
 
 \param list the name of the list it was added to or nil
 */
- (void)reportPayloadReceivedOntoList:(nullable NSString*)list;

/** \brief Mark payload rejected */
- (void)reportPayloadRejected;

@end

/**
 \brief A container for one or more AADetailedListItems.  This payload is delivered via an internal ad.
 */
@interface AAAdContent : NSObject

/** The ad associated with this ad content */
@property (nonnull) id ad;

/** array of items */
@property (nonnull) NSArray<AADetailedListItem*> *detailedListItems;

/** Acknowledge items were successfully added to a list. */
- (void)acknowledge;

/** Report failure to add items to a list. */
- (void)failure:(nullable NSString *)message;

/** For AdAdapted use */
/**
 Create from a dictionary
 
 \param dictionary Dictionary describing json from the API.
 \param ad Ad associated with this content. */
+(nullable instancetype)parseFromDictionary:(nullable NSDictionary*)dictionary forAd:(nonnull id)ad;

@end
